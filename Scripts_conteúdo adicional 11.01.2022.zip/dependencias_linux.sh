#Para instalação das dependências necessárias ao SO linux, execute o comando abaixo antes de instalar as libraries 
sudo apt install libgdal-dev \
 libssl-dev \
 libxml2-dev \
 libudunits2-dev \
 libprotobuf-dev \
 protobuf-compiler \
 libjq-dev
